<?php
	class TravelHistory {
		public $depart;
		public $arrive;
		public $travelDate;
		public $leasedModel;
	}
?>